export const PLANS = {
  free: { name: "Free", monthlyPrice: 0, requests: 20 },
  pro: { name: "Pro", monthlyPrice: 19, requests: 500 },
  business: { name: "Business", monthlyPrice: 49, requests: 2000 },
} as const;

export type PlanId = keyof typeof PLANS;

export function planFromPriceId(priceId?: string | null): PlanId {
  if (priceId && priceId === process.env.STRIPE_PRICE_BUSINESS) return "business";
  if (priceId && priceId === process.env.STRIPE_PRICE_PRO) return "pro";
  return "free";
}
