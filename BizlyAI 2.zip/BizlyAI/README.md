# Bizly AI — MVP 0.2

A bilingual (English/Russian) SaaS starter with Supabase authentication, per-user business profiles and conversation history, Stripe subscription checkout/portal/webhooks, and server-enforced monthly AI request quotas.

## Stack
- Next.js 14 App Router + TypeScript
- Supabase Auth + Postgres + Row Level Security
- OpenAI API (server-side)
- Stripe Checkout + Billing Portal + signed webhooks

## 1. Create and configure Supabase
1. Create a Supabase project.
2. In SQL Editor, run `supabase/schema.sql`.
3. In Authentication -> URL Configuration, set your local Site URL to `http://localhost:3000` and add `http://localhost:3000/auth/callback` to Redirect URLs.
4. Copy Project URL, anon key and service-role key into `.env.local`.
5. Keep the service-role key private. It bypasses RLS and must never be exposed to browser code.

## 2. Configure Stripe
1. Create two recurring monthly prices in Stripe: Pro (€19/month) and Business (€49/month).
2. Copy their Price IDs to `STRIPE_PRICE_PRO` and `STRIPE_PRICE_BUSINESS`.
3. Configure the Customer Portal in Stripe Dashboard.
4. Add a webhook endpoint at `https://YOUR_DOMAIN/api/stripe/webhook` (locally use Stripe CLI forwarding).
5. Subscribe to `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, and `checkout.session.completed`.
6. Put the webhook signing secret in `STRIPE_WEBHOOK_SECRET`.
7. For local testing, run `stripe listen --forward-to localhost:3000/api/stripe/webhook` and copy its `whsec_...` secret.

## 3. Configure and run
1. Use Node.js 20+.
2. Copy `.env.example` to `.env.local` and fill every value.
3. Run `npm install`.
4. Run `npm run dev`; open `http://localhost:3000`.
5. Test sign-up, confirm email if enabled, log in, save a business profile, start conversations, and inspect rows in Supabase.
6. Test paid subscriptions using Stripe test mode and test card `4242 4242 4242 4242` with a future expiry and any CVC.

## 4. Included
- Email/password registration and login
- Supabase session cookies via middleware
- Authenticated workspace
- Business profile stored in Postgres
- Conversation list and persisted messages
- OpenAI chat route with server-side authentication
- Monthly request metering enforced through atomic Postgres RPC
- Free / Pro / Business tiers: 20 / 500 / 2,000 requests per UTC calendar month
- Stripe Checkout for Pro and Business
- Stripe Billing Portal
- Signed Stripe webhook updates subscription records

## Important implementation notes
- Configure Supabase email confirmation and production redirect URLs before launch.
- Stripe webhooks are the source of truth for paid subscription status. Never trust a plan sent by the browser.
- Service role is used only in server routes for trusted message persistence and webhook updates. Keep it secret.
- This starter increments usage before the OpenAI call; failed model calls may consume one request. Add refunds/reconciliation if you want exact billing.
- The quota period currently uses UTC calendar months for every plan. If you prefer Stripe billing-cycle quotas, adjust the SQL and quota logic.
- The chat endpoint caps input and loads the latest 20 saved messages. Add rate limiting, token budgets, moderation, and request idempotency before production.
- The dashboard is a starter implementation; add robust error boundaries, account deletion/export, privacy policy, terms, cookie controls where required, and monitoring before public launch.
- Stripe product tax/VAT settings, invoices, customer portal configuration, and local legal requirements must be reviewed for each launch market.

## Environment variables
See `.env.example`. Never prefix private secrets with `NEXT_PUBLIC_`.

## Production checklist
- Enable Supabase email confirmation, strong password policy and optional MFA.
- Set production `NEXT_PUBLIC_APP_URL`, Supabase auth redirect URLs and Stripe webhook URL.
- Rotate keys if they were ever committed or shared.
- Configure Stripe tax and billing portal settings as appropriate.
- Add server-side rate limiting and abuse prevention.
- Add GDPR-compliant privacy notice, data retention/deletion/export workflows, and support contact.
- Run `npm run typecheck` and `npm run build` with real environment variables.
