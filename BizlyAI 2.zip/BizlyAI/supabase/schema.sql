-- Run in Supabase SQL Editor. Enables per-user isolation and server-side quota accounting.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  language text not null default 'en' check (language in ('en','ru')),
  stripe_customer_id text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  business_type text not null default '',
  target_audience text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'New conversation',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists conversations_user_updated_idx on public.conversations(user_id, updated_at desc);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 12000),
  created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  stripe_customer_id text,
  stripe_subscription_id text unique,
  stripe_price_id text,
  plan text not null default 'free' check (plan in ('free','pro','business')),
  status text not null default 'free',
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists public.usage_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  period_start date not null,
  request_count integer not null default 0 check (request_count >= 0),
  updated_at timestamptz not null default now(),
  unique(user_id, period_start)
);

-- Create a profile and free subscription when a new auth user is registered.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''))
  on conflict (id) do nothing;
  insert into public.subscriptions(user_id, plan, status) values (new.id, 'free', 'free')
  on conflict (user_id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.businesses enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.subscriptions enable row level security;
alter table public.usage_events enable row level security;

create policy "profiles select own" on public.profiles for select using (auth.uid() = id);
create policy "profiles update own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "businesses own all" on public.businesses for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "conversations own all" on public.conversations for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "messages own all" on public.messages for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "subscriptions select own" on public.subscriptions for select using (auth.uid() = user_id);
create policy "usage select own" on public.usage_events for select using (auth.uid() = user_id);

-- Atomic quota consumption: concurrent requests cannot overspend the monthly allowance.
create or replace function public.consume_ai_request(p_user_id uuid, p_limit integer)
returns table(allowed boolean, used integer, period_start date)
language plpgsql security definer set search_path = public as $$
declare
  v_period date := date_trunc('month', now() at time zone 'utc')::date;
  v_used integer;
begin
  if auth.uid() is distinct from p_user_id then
    raise exception 'Not authorized';
  end if;
  insert into public.usage_events(user_id, period_start, request_count)
  values (p_user_id, v_period, 0)
  on conflict (user_id, period_start) do nothing;

  update public.usage_events
  set request_count = request_count + 1, updated_at = now()
  where user_id = p_user_id and period_start = v_period and request_count < p_limit
  returning request_count into v_used;

  if v_used is not null then
    return query select true, v_used, v_period;
  else
    select request_count into v_used from public.usage_events
    where user_id = p_user_id and period_start = v_period;
    return query select false, coalesce(v_used,0), v_period;
  end if;
end; $$;

create or replace function public.get_monthly_usage(p_user_id uuid)
returns table(used integer)
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is distinct from p_user_id then raise exception 'Not authorized'; end if;
  return query select coalesce((select u.request_count from public.usage_events u
    where u.user_id=p_user_id and u.period_start=date_trunc('month', now() at time zone 'utc')::date),0);
end; $$;

revoke all on function public.consume_ai_request(uuid,integer) from public;
revoke all on function public.get_monthly_usage(uuid) from public;
grant execute on function public.consume_ai_request(uuid,integer) to authenticated;
grant execute on function public.get_monthly_usage(uuid) to authenticated;
