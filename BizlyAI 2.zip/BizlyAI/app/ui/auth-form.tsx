'use client';
import { useState } from "react";
import { createClient } from "../../lib/supabase/client";
export function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [busy,setBusy]=useState(false); const [note,setNote]=useState("");
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNote("");
    const supabase=createClient();
    const result = mode==="signup"
      ? await supabase.auth.signUp({email,password, options:{emailRedirectTo: `${window.location.origin}/auth/callback`}})
      : await supabase.auth.signInWithPassword({email,password});
    setBusy(false);
    if(result.error){setNote(result.error.message);return;}
    if(mode==="signup" && !result.data.session){setNote("Check your email to confirm your account, then log in.");return;}
    window.location.href="/app";
  }
  return <form onSubmit={submit} className="form"><label>Email<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@company.com"/></label><label>Password<input type="password" minLength={8} autoComplete={mode==="login"?"current-password":"new-password"} required value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters"/></label><button className="button full" disabled={busy}>{busy?"Please wait…":mode==="signup"?"Create account":"Log in"}</button>{note&&<p className="notice">{note}</p>}</form>;
}
