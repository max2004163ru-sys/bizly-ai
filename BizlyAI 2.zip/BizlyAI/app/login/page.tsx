import Link from "next/link";
import { AuthForm } from "../ui/auth-form";
export default function LoginPage() { return <main className="authPage"><Link className="logo" href="/">✳ Bizly AI</Link><div className="authCard"><span className="eyebrow">WELCOME BACK</span><h1>Log in to Bizly</h1><p>Continue building a better business day.</p><AuthForm mode="login"/></div></main>; }
