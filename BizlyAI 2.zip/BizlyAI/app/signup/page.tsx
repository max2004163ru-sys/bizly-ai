import Link from "next/link";
import { AuthForm } from "../ui/auth-form";
export default function SignupPage() { return <main className="authPage"><Link className="logo" href="/">✳ Bizly AI</Link><div className="authCard"><span className="eyebrow">START FOR FREE</span><h1>Create your account</h1><p>Your AI business workspace is a few steps away.</p><AuthForm mode="signup"/></div></main>; }
