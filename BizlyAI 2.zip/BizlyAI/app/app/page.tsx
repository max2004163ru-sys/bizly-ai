import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "../../lib/supabase/server";
import { Workspace } from "../ui/workspace";
import { PLANS } from "../../lib/plans";

export default async function AppPage() {
  const supabase=createClient();
  const {data:{user}}=await supabase.auth.getUser();
  if(!user) redirect("/login");
  const [{data:profile},{data:subscription},{data:conversations},{data:businesses}] = await Promise.all([
    supabase.from("profiles").select("full_name,language").eq("id",user.id).maybeSingle(),
    supabase.from("subscriptions").select("plan,status,current_period_end").eq("user_id",user.id).maybeSingle(),
    supabase.from("conversations").select("id,title,updated_at").eq("user_id",user.id).order("updated_at",{ascending:false}).limit(30),
    supabase.from("businesses").select("id,name,business_type,target_audience").eq("user_id",user.id).limit(1)
  ]);
  const plan=(subscription?.status==="active"||subscription?.status==="trialing")?(subscription.plan as keyof typeof PLANS):"free";
  const business=businesses?.[0]||null;
  const {data:usage}=await supabase.rpc("get_monthly_usage",{p_user_id:user.id});
  const used=usage?.[0]?.used ?? 0;
  return <main className="workspacePage"><header className="top"><Link className="logo" href="/">✳ Bizly AI</Link><div className="userTop">{user.email}<form action="/api/auth/signout" method="post"><button className="button secondary small">Sign out</button></form></div></header><Workspace userId={user.id} email={user.email||""} initialBusiness={business} initialConversations={conversations||[]} plan={plan} used={used} limit={PLANS[plan].requests} language={profile?.language||"en"}/></main>;
}
