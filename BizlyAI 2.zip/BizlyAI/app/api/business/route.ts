import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";
export async function POST(req:Request){
 const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const body=await req.json();const name=String(body.name||"").trim().slice(0,120);if(!name)return NextResponse.json({error:"Business name is required."},{status:400});
 const {data:existing}=await supabase.from("businesses").select("id").eq("user_id",user.id).limit(1).maybeSingle();
 const payload={user_id:user.id,name,business_type:String(body.business_type||"").slice(0,120),target_audience:String(body.target_audience||"").slice(0,300)};
 const result=existing?await supabase.from("businesses").update(payload).eq("id",existing.id).select().single():await supabase.from("businesses").insert(payload).select().single();
 if(result.error)return NextResponse.json({error:result.error.message},{status:400});return NextResponse.json({business:result.data});
}
