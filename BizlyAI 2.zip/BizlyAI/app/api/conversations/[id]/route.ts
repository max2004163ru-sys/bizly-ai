import { NextResponse } from "next/server";
import { createClient } from "../../../../lib/supabase/server";
export async function GET(_req:Request,{params}:{params:{id:string}}){
 const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const {data:conversation}=await supabase.from("conversations").select("id").eq("id",params.id).eq("user_id",user.id).maybeSingle();if(!conversation)return NextResponse.json({error:"Not found"},{status:404});
 const {data:messages,error}=await supabase.from("messages").select("id,role,content,created_at").eq("conversation_id",params.id).eq("user_id",user.id).order("created_at",{ascending:true});
 if(error)return NextResponse.json({error:error.message},{status:500});return NextResponse.json({messages});
}
