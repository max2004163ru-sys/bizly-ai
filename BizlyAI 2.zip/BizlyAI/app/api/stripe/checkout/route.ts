import { NextResponse } from "next/server";
import { createClient } from "../../../../lib/supabase/server";
import { createAdminClient } from "../../../../lib/supabase/admin";
import { getStripe } from "../../../../lib/stripe";
export async function POST(req:Request){
 try{
  const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
  const {plan}=await req.json();if(!["pro","business"].includes(plan))return NextResponse.json({error:"Invalid plan."},{status:400});
  const price=plan==="pro"?process.env.STRIPE_PRICE_PRO:process.env.STRIPE_PRICE_BUSINESS;if(!price)return NextResponse.json({error:"Stripe price ID is not configured."},{status:503});
  const admin=createAdminClient();const {data:profile}=await admin.from("profiles").select("stripe_customer_id").eq("id",user.id).maybeSingle();
  const stripe=getStripe();let customerId=profile?.stripe_customer_id;
  if(!customerId){const customer=await stripe.customers.create({email:user.email,metadata:{supabase_user_id:user.id}});customerId=customer.id;await admin.from("profiles").upsert({id:user.id,stripe_customer_id:customerId},{onConflict:"id"});}
  const session=await stripe.checkout.sessions.create({mode:"subscription",customer:customerId,line_items:[{price,quantity:1}],allow_promotion_codes:true,success_url:`${process.env.NEXT_PUBLIC_APP_URL}/app?billing=success`,cancel_url:`${process.env.NEXT_PUBLIC_APP_URL}/app?billing=cancelled`,client_reference_id:user.id,metadata:{supabase_user_id:user.id,plan},subscription_data:{metadata:{supabase_user_id:user.id,plan}}});
  return NextResponse.json({url:session.url});
 }catch(e){console.error(e);return NextResponse.json({error:"Could not start checkout."},{status:500});}
}
