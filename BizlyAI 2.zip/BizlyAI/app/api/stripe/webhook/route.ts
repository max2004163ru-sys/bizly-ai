import { NextResponse } from "next/server";
import Stripe from "stripe";
import { getStripe } from "../../../../lib/stripe";
import { createAdminClient } from "../../../../lib/supabase/admin";
import { planFromPriceId } from "../../../../lib/plans";

export const runtime="nodejs";
export async function POST(req:Request){
 const signature=req.headers.get("stripe-signature");if(!signature||!process.env.STRIPE_WEBHOOK_SECRET)return NextResponse.json({error:"Webhook signature configuration missing."},{status:400});
 let event:Stripe.Event;
 try{event=getStripe().webhooks.constructEvent(await req.text(),signature,process.env.STRIPE_WEBHOOK_SECRET);}catch(e:any){return NextResponse.json({error:`Webhook signature verification failed: ${e.message}`},{status:400});}
 const admin=createAdminClient();
 try{
  if(["customer.subscription.created","customer.subscription.updated","customer.subscription.deleted"].includes(event.type)){
   const subscription=event.data.object as Stripe.Subscription;
   const customerId=typeof subscription.customer==="string"?subscription.customer:subscription.customer.id;
   const {data:profile}=await admin.from("profiles").select("id").eq("stripe_customer_id",customerId).maybeSingle();
   const userId=subscription.metadata.supabase_user_id||profile?.id;
   if(!userId)return NextResponse.json({received:true,ignored:"No mapped user"});
   const priceId=subscription.items.data[0]?.price.id;
   const plan=subscription.status==="active"||subscription.status==="trialing"?planFromPriceId(priceId):"free";
   const periodStart=(subscription as any).current_period_start;
   const periodEnd=(subscription as any).current_period_end;
   const {error}=await admin.from("subscriptions").upsert({
    user_id:userId,stripe_customer_id:customerId,stripe_subscription_id:subscription.id,
    stripe_price_id:priceId||null,plan,status:subscription.status,
    current_period_start:periodStart?new Date(periodStart*1000).toISOString():null,
    current_period_end:periodEnd?new Date(periodEnd*1000).toISOString():null,
    cancel_at_period_end:subscription.cancel_at_period_end,updated_at:new Date().toISOString()
   },{onConflict:"user_id"});
   if(error)throw error;
  }
  if(event.type==="checkout.session.completed"){
   const session=event.data.object as Stripe.Checkout.Session;
   if(session.customer&&session.client_reference_id){
    await admin.from("profiles").upsert({id:session.client_reference_id,stripe_customer_id:String(session.customer)},{onConflict:"id"});
   }
  }
  return NextResponse.json({received:true});
 }catch(e){console.error("Stripe webhook processing failed",e);return NextResponse.json({error:"Webhook processing failed."},{status:500});}
}
