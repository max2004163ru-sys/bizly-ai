import { NextResponse } from "next/server";
import { createClient } from "../../../../lib/supabase/server";
import { createAdminClient } from "../../../../lib/supabase/admin";
import { getStripe } from "../../../../lib/stripe";
export async function POST(){
 try{const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const admin=createAdminClient();const {data:profile}=await admin.from("profiles").select("stripe_customer_id").eq("id",user.id).maybeSingle();if(!profile?.stripe_customer_id)return NextResponse.json({error:"No Stripe customer found. Choose a paid plan first."},{status:400});
 const session=await getStripe().billingPortal.sessions.create({customer:profile.stripe_customer_id,return_url:`${process.env.NEXT_PUBLIC_APP_URL}/app`});return NextResponse.json({url:session.url});
 }catch(e){console.error(e);return NextResponse.json({error:"Could not open billing portal."},{status:500});}
}
