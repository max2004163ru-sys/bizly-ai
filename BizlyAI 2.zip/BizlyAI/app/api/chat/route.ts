import OpenAI from "openai";
import { NextResponse } from "next/server";
import { createClient } from "../../../lib/supabase/server";
import { createAdminClient } from "../../../lib/supabase/admin";
import { PLANS, type PlanId } from "../../../lib/plans";

export const runtime="nodejs";
const openai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
export async function POST(req:Request){
 try{
  const supabase=createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return NextResponse.json({error:"Please log in."},{status:401});
  if(!process.env.OPENAI_API_KEY)return NextResponse.json({error:"AI service is not configured."},{status:503});
  const body=await req.json();const message=String(body.message||"").trim();if(!message||message.length>5000)return NextResponse.json({error:"Message must be between 1 and 5,000 characters."},{status:400});
  const {data:sub}=await supabase.from("subscriptions").select("plan,status").eq("user_id",user.id).maybeSingle();
  const plan:PlanId=(sub&&(sub.status==="active"||sub.status==="trialing")?sub.plan:"free") as PlanId;
  const limit=PLANS[plan]?.requests??PLANS.free.requests;
  const {data:quota,error:quotaError}=await supabase.rpc("consume_ai_request",{p_user_id:user.id,p_limit:limit});
  if(quotaError)return NextResponse.json({error:"Could not verify usage limit."},{status:500});
  if(!quota?.[0]?.allowed)return NextResponse.json({error:`Monthly AI limit reached (${limit}). Upgrade your plan to continue.`,used:quota?.[0]?.used,limit},{status:429});
  let conversationId=String(body.conversationId||"");
  if(conversationId){
   const {data:owned}=await supabase.from("conversations").select("id").eq("id",conversationId).eq("user_id",user.id).maybeSingle();
   if(!owned)return NextResponse.json({error:"Conversation not found."},{status:404});
  }else{
   const title=message.replace(/\s+/g," ").slice(0,64);
   const {data:newConversation,error}=await supabase.from("conversations").insert({user_id:user.id,title}).select("id").single();
   if(error||!newConversation)return NextResponse.json({error:"Could not create conversation."},{status:500});
   conversationId=newConversation.id;
  }
  const [{data:business},{data:history}] = await Promise.all([
   supabase.from("businesses").select("name,business_type,target_audience").eq("user_id",user.id).limit(1).maybeSingle(),
   supabase.from("messages").select("role,content").eq("conversation_id",conversationId).eq("user_id",user.id).order("created_at",{ascending:true}).limit(20)
  ]);
  const lang=body.language==="ru"?"Russian":"English";
  const context=`Company: ${business?.name||"not specified"}; type: ${business?.business_type||"not specified"}; customers: ${business?.target_audience||"not specified"}.`;
  const completion=await openai.chat.completions.create({model:process.env.OPENAI_MODEL||"gpt-4.1-mini",temperature:0.6,messages:[
   {role:"system",content:`You are Bizly AI, a practical assistant for small businesses. Respond in ${lang}. Give clear, useful, commercially realistic answers. Draft content for the owner to review. Never claim to have sent messages, published content, accessed accounts or completed external actions. Ask at most one clarifying question. Do not present legal, tax, investment or medical guidance as professional advice. Business context: ${context}`},
   ...(history||[]).map((m:any)=>({role:m.role as "user"|"assistant",content:m.content})),
   {role:"user",content:message}
  ]});
  const reply=completion.choices[0]?.message?.content||"I couldn't generate a response. Please try again.";
  const admin=createAdminClient();
  const {error:saveError}=await admin.from("messages").insert([
   {user_id:user.id,conversation_id:conversationId,role:"user",content:message},
   {user_id:user.id,conversation_id:conversationId,role:"assistant",content:reply}
  ]);
  if(saveError)return NextResponse.json({error:"Reply generated but could not be saved. Please retry."},{status:500});
  await admin.from("conversations").update({updated_at:new Date().toISOString()}).eq("id",conversationId).eq("user_id",user.id);
  return NextResponse.json({reply,conversationId,used:quota[0].used});
 }catch(e){console.error(e);return NextResponse.json({error:"The assistant is temporarily unavailable."},{status:500});}
}
