import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Bizly AI", description: "Your AI business assistant." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
